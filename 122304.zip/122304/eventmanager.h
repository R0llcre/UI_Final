#ifndef EVENTMANAGER_H
#define EVENTMANAGER_H

#include <QObject>
#include <QtAV>

class ToolFrame;
class EventManager : public QObject
{
    Q_OBJECT
public:
    explicit EventManager(QtAV::AVPlayer *player,QObject *parent = nullptr);

    void setParentWidget(QWidget* widget) { m_parentWidget = widget;}
    void setToolWidget(ToolFrame* widget) {m_widget = widget;}
signals:

protected:
    virtual bool eventFilter(QObject *, QEvent *);

private:
    QtAV::AVPlayer *m_player;
    ToolFrame* m_widget;
    QWidget* m_parentWidget;
};

#endif // EVENTMANAGER_H
