#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "toolframe.h"

class MediaPlayer;

class QPushButton;
class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

public slots:
private slots:
    void on_pushButton_clicked(bool  flag);


    void onSelectFile(QString file);
protected:
    bool eventFilter(QObject *watched, QEvent *event);
private:
    void loadStyle();

private:
    ToolFrame* m_toolFrame;

    QTimer* m_timer;

    MediaPlayer* m_player;

    QPushButton* mpPlayPauseBtn;
};
#endif // WIDGET_H
