#ifndef TOOLFRAME_H
#define TOOLFRAME_H

#include <QFrame>
#include <QSlider>
#include <QTimer>
#include <QtAV>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include "Slider.h"


class QLabel;
class QPushButton;
class PlayListForm;

namespace QtAV {
class VideoPreviewWidget;
class AVPlayer;
}

class ToolFrame : public QFrame
{
    Q_OBJECT

public:
    explicit ToolFrame(QWidget *parent = nullptr);
    ~ToolFrame();

    void setProxyPlayer(QtAV::AVPlayer* p);
    void setParentWidget(QWidget* widget) { m_parentWidget = widget;}

    bool contanisButtomWidget();

    bool contanisPlaylistWidget();

    void mouseMove(QPoint pos);

    Slider* timeSlider() const;

    Slider* volumeSlider() const;

    QLabel* timeLabel() const;

    QPushButton* playButton() const;


    QFrame* buttomWidget() const;


    void showFullOrNormal();


    void setVideoIO(QtAV::VideoOutput* io);

signals:
    void sigSelectFile(QString fileName);

public slots:
    void setVolume();

    void onStartPlay();

    void onStopPlay();

    void onPositionChange(qint64 pos);

    void seek(int value);
    void seek();


    void onUpdatePreView(int pos, int value);

    void onTimeSliderLeave();

    void onMediaStateChanged();

protected:
    void showEvent(QShowEvent *event);

    bool eventFilter(QObject *obj, QEvent *event);

private:
    void initUi();

private slots:
    void sltTimer();

    void on_tool_fileBtn_clicked(bool flag);

    void on_tool_maxBtn_clicked();

    void on_tool_stopBtn_clicked();

    void on_tool_stateBtn_clicked();

    void on_tool_preBtn_clicked();


    void on_tool_nextBtn_clicked();

private:
    void setupUi(QFrame *ToolFrame);
    void retranslateUi(QFrame *ToolFrame);


private:
    int m_state{2}; //> 0:单曲   1:顺序播放  2:列表播放

    PlayListForm* m_playListForm;

    QWidget* m_parentWidget;

    QVBoxLayout *verticalLayout_2;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    Slider *timeSlider_;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *tool_playBtn;
    QPushButton *tool_stopBtn;
    QPushButton *tool_stateBtn;

    QPushButton *tool_preBtn;
    QPushButton *tool_nextBtn;
    QLabel *tool_timelabel;
    QSpacerItem *horizontalSpacer;
    QPushButton *tool_volumeBtn;
    Slider *volumeSlider_;
    QLabel *label_volume;
    QPushButton *tool_fileBtn;
    QPushButton *tool_maxBtn;
    QSpacerItem *horizontalSpacer_3;


    QTimer* m_timer;

    QtAV::VideoPreviewWidget *m_preview{nullptr};
    QLabel* m_preTimeLabel{nullptr};
    QtAV::AVPlayer *mpPlayer;
};

#endif // TOOLFRAME_H
