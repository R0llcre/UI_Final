#include "eventmanager.h"
#include <QKeyEvent>
#include <QWidget>
#include <QtAV/AudioOutput.h>
#include "toolframe.h"
using namespace QtAV;

EventManager::EventManager(QtAV::AVPlayer *player, QObject *parent) : QObject(parent),
    m_player(player)
{

}

bool EventManager::eventFilter(QObject *watched, QEvent *event)
{
    if (!m_player || !m_player->renderer() || !m_player->renderer()->widget())
        return false;

    if (qobject_cast<QWidget*>(watched) != m_player->renderer()->widget())
    {
        return false;
    }

    QEvent::Type type = event->type();
    switch (type)
    {
    case QEvent::KeyPress:
    {


        QKeyEvent *key_event = static_cast<QKeyEvent*>(event);
        int key = key_event->key();
        Qt::KeyboardModifiers modifiers = key_event->modifiers();


        switch (key)
        {
        case Qt::Key_Up:
        {
            AudioOutput *ao = m_player->audio();
            if (ao && ao->isAvailable())
            {
                int v = m_widget->volumeSlider()->value();
                v += 10;
                m_widget->volumeSlider()->setValue(v);
            }
        }
            break;
        case Qt::Key_Down:
        {
            AudioOutput *ao = m_player->audio();
            if (ao && ao->isAvailable())
            {
                int v = m_widget->volumeSlider()->value();
                v -= 10;
                m_widget->volumeSlider()->setValue(v);
            }
        }
            break;
        case Qt::Key_Left:
        {
            m_player->setSeekType(key_event->isAutoRepeat() ? KeyFrameSeek : AccurateSeek);
            m_player->seekBackward();

        }
            break;
        case Qt::Key_Right:
        {
            m_player->setSeekType(key_event->isAutoRepeat() ? KeyFrameSeek : AccurateSeek);
            m_player->seekForward();

        }
            break;
        case Qt::Key_Escape:
        {
            m_widget->showFullOrNormal();
        }
            break;
        case Qt::Key_Space:
        {
            if (!m_player->isPlaying()) {
                m_player->play();
                return false;
            }
            m_player->pause(!m_player->isPaused());

        }
            break;
        default:
            return false;
        }

    }
        break;
    case QEvent::MouseButtonDblClick:
    {


        if(m_widget->isVisible() && (m_widget->contanisButtomWidget()))
            return false;


        QMouseEvent *me = static_cast<QMouseEvent*>(event);
        Qt::MouseButton mbt = me->button();
        if (mbt == Qt::LeftButton)
        {
            m_widget->showFullOrNormal();
        }
        break;
    }
    case QEvent::MouseButtonRelease:
    {
        if(m_widget->isVisible() && (m_widget->contanisButtomWidget()))
            return false;

        QMouseEvent *me = static_cast<QMouseEvent*>(event);
        Qt::MouseButton mbt = me->button();
        if (mbt == Qt::LeftButton)
        {
            if (!m_player->isPlaying()) {
                m_player->play();
                return false;
            }
            m_player->pause(!m_player->isPaused());

        }
        break;
    }
    default:
        return false;

    }

    return false;
}
