#include "mediaplayer.h"
#include <QDebug>
#include <QFile>
#include <QMessageBox>

using namespace QtAV;

MediaPlayer::MediaPlayer(QObject *parent) : QObject(parent)
{
    m_vo = new VideoOutput(this);
    if (!m_vo->widget()) {
        QMessageBox::warning(0, QString::fromLatin1("QtAV error"), tr("Can not create video renderer"));
        return;
    }

    m_player = new AVPlayer(this);
    m_player->setRenderer(m_vo);
    m_player->setSpeedTime(5000);


//    // 设置清晰度
//    m_vo->setBrightness(1.0);  // 亮度
//    m_vo->setContrast(1.0);    // 对比度
//    m_vo->setSaturation(1.0);  // 饱和度
//    m_vo->setHue(0.0);         // 色调

}

MediaPlayer::~MediaPlayer()
{
}

QWidget *MediaPlayer::videoWidget()
{
    return m_vo->widget();
}

AVPlayer *MediaPlayer::player()
{
    return m_player;
}


void MediaPlayer::setMedia(const QString &file)
{
    if(m_player->isPlaying())
    {
        m_player->stop();
    }

    m_file = "";
    m_player->setFile(file);
    if(m_player->load())
    {
        m_file = file;
    }
}

void MediaPlayer::playPause()
{
    if (!m_player->isPlaying()) {
        m_player->play();
        return;
    }
    m_player->pause(!m_player->isPaused());

}

void MediaPlayer::stop()
{
    m_player->stop();
}

VideoOutput *MediaPlayer::videoIO()
{
    return m_vo;
}

void MediaPlayer::togglePlayPause()
{
    if (m_player->isPlaying())
    {
        m_player->pause(!m_player->isPaused());
    }
    else
    {
        if (m_file.isEmpty())
            return;
        if (!m_player->isPlaying())
            m_player->play(m_file);
        else
            m_player->play();
    }

}




