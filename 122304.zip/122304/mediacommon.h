#ifndef MEDIACOMMON_H
#define MEDIACOMMON_H

#include <QObject>
#include <QtAV>
#include <QtAV/OpenGLVideo.h>
#include <QtAV/VideoShaderObject.h>
#include <QtAVWidgets>

const qreal kVolumeInterval = 0.04;

extern double g_speedTimeMS;

using namespace QtAV;

enum ToolSpeed
{
    Speed_0_5,
    Speed_1_0,
    Speed_1_5,
    Speed_2_0,
};

enum ToolTime
{
    Time_5,
    Time_10,
    Time_15,
    Time_30,
};

static double getToolSpeed(ToolSpeed s)
{
    switch (s) {
    case Speed_0_5:             return 0.5;
    case Speed_1_0:             return 1.0;
    case Speed_1_5:             return 1.5;
    case Speed_2_0:             return 2.0;
    default:                    return 1.0;
    }
}

static int getToolTime(ToolTime s)
{
    switch (s) {
    case Time_5:              return 5 * 1000;
    case Time_10:             return 10 * 1000;
    case Time_15:             return 15 * 1000;
    case Time_30:             return 30 * 1000;
    default:                  return 0 * 1000;
    }
}

static ToolSpeed getEnumToolSpeed(double value)
{
    if(value == 0.5)
    {
        return Speed_0_5;
    }
    else if(value == 1.0)
    {
        return Speed_1_0;
    }
    else if(value == 1.5)
    {
        return Speed_1_5;
    }
    else if(value == 2.0)
    {
        return Speed_2_0;
    }

    return Speed_1_0;
}

static ToolTime getEnumToolTime(int value)
{
    if(value == 5 * 1000)
    {
        return Time_5;
    }
    else if(value == 10 * 1000)
    {
        return Time_10;
    }
    else if(value == 15 * 1000)
    {
        return Time_15;
    }
    else if(value == 30 * 1000)
    {
        return Time_30;
    }

    return Time_5;
}


#endif // MEDIACOMMON_H
