#ifndef PLAYLISTFORM_H
#define PLAYLISTFORM_H

#include <QListWidget>
#include <QWidget>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

namespace Ui {
class PlayListForm;
}

namespace QtAV {
class VideoOutput;
}


class PlayListForm : public QWidget
{
    Q_OBJECT

public:
    explicit PlayListForm(QWidget *parent = nullptr);
    ~PlayListForm();


    void setVideoIO(QtAV::VideoOutput* io);

    int currentIndex();

    int playsSize();

    QString playNameByRow(int row);

    void setCurrentItem(int row);

    QString currentName();
signals:
    void sigSelectFile(QString fileName);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);

    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_2_valueChanged(int value);

    void on_horizontalSlider_3_valueChanged(int value);

    void on_horizontalSlider_4_valueChanged(int value);


private:
    void setupUi(QWidget *PlayListForm);
    void retranslateUi(QWidget *PlayListForm);


private:
    Ui::PlayListForm *ui;
    QtAV::VideoOutput* m_io;

    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QListWidget *listWidget;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout;
    QSlider *horizontalSlider;
    QLabel *label_qx_1;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout_2;
    QSlider *horizontalSlider_2;
    QLabel *label_qx_2;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_3;
    QSlider *horizontalSlider_3;
    QLabel *label_qx_3;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_4;
    QSlider *horizontalSlider_4;
    QLabel *label_qx_4;


};

#endif // PLAYLISTFORM_H
