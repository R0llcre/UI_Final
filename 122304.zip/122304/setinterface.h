#ifndef SETINTERFACE_H
#define SETINTERFACE_H

#include <QObject>
#include <QSettings>

/**
 * @brief The SetInterface class        配置文件或注册表读写
 */
class SetInterface : public QObject
{
    Q_OBJECT
public:
    explicit SetInterface(const QString& filename,QObject *parent = nullptr);

    explicit SetInterface(QObject *parent = nullptr);

    ~SetInterface();

    void setValue(const QString& groupname,const QString& key,const QVariant& value);

    QVariant getValue(const QString& groupname,const QString& key,QVariant defaultValue=QVariant());
signals:


private:
    QSettings* m_set;
};

#endif // SETINTERFACE_H
