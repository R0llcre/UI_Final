#include "toolframe.h"

#include <QMouseEvent>
#include <QDebug>
#include <qpainter.h>
#include <QTime>
#include <QFileDialog>
#include <QtAV>
#include <QtAV/OpenGLVideo.h>
#include <QtAV/VideoShaderObject.h>
#include <QApplication>
#include <QtAVWidgets>
#include "playlistform.h"
#include "mediacommon.h"
#include <QMessageBox>

using namespace QtAV;


ToolFrame::ToolFrame(QWidget *parent) :
    QFrame(parent)
{
    setupUi(this);

    m_timer = new QTimer(this);
    m_timer->setInterval(5000);
    connect(m_timer,&QTimer::timeout,this,&ToolFrame::sltTimer);


    initUi();

}

ToolFrame::~ToolFrame()
{
}

void ToolFrame::setupUi(QFrame *ToolFrame)
{
    if (ToolFrame->objectName().isEmpty())
        ToolFrame->setObjectName(QString::fromUtf8("ToolFrame"));
    ToolFrame->resize(881, 71);
    verticalLayout_2 = new QVBoxLayout(ToolFrame);
    verticalLayout_2->setSpacing(1);
    verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
    verticalLayout_2->setContentsMargins(1, 1, 1, 1);
    frame = new QFrame(ToolFrame);
    frame->setObjectName(QString::fromUtf8("frame"));
    frame->setFrameShape(QFrame::StyledPanel);
    frame->setFrameShadow(QFrame::Raised);
    verticalLayout = new QVBoxLayout(frame);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    verticalLayout->setContentsMargins(1, 1, 1, 1);
    timeSlider_ = new Slider(frame);
    timeSlider_->setObjectName(QString::fromUtf8("timeSlider"));
    timeSlider_->setCursor(QCursor(Qt::PointingHandCursor));
    timeSlider_->setOrientation(Qt::Horizontal);

    verticalLayout->addWidget(timeSlider_);

    horizontalLayout = new QHBoxLayout();
    horizontalLayout->setSpacing(15);
    horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
    horizontalSpacer_2 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

    horizontalLayout->addItem(horizontalSpacer_2);

    tool_playBtn = new QPushButton(frame);
    tool_playBtn->setObjectName(QString::fromUtf8("tool_playBtn"));
    tool_playBtn->setMinimumSize(QSize(35, 35));
    tool_playBtn->setMaximumSize(QSize(35, 35));
    tool_playBtn->setCursor(QCursor(Qt::PointingHandCursor));
    tool_playBtn->setCheckable(true);

    horizontalLayout->addWidget(tool_playBtn);

    tool_stopBtn = new QPushButton(frame);
    tool_stopBtn->setObjectName(QString::fromUtf8("tool_stopBtn"));
    tool_stopBtn->setMinimumSize(QSize(35, 35));
    tool_stopBtn->setMaximumSize(QSize(35, 35));
    tool_stopBtn->setCursor(QCursor(Qt::PointingHandCursor));
    tool_stopBtn->setCheckable(true);
    horizontalLayout->addWidget(tool_stopBtn);


    tool_stateBtn = new QPushButton(frame);
    tool_stateBtn->setObjectName(QString::fromUtf8("tool_stateBtn"));
    tool_stateBtn->setMinimumSize(QSize(35, 35));
    tool_stateBtn->setMaximumSize(QSize(35, 35));
    tool_stateBtn->setCursor(QCursor(Qt::PointingHandCursor));
    tool_stateBtn->setText("L");
    tool_stateBtn->setToolTip("List Loop");
    horizontalLayout->addWidget(tool_stateBtn);

    tool_preBtn = new QPushButton(frame);
    tool_preBtn->setObjectName(QString::fromUtf8("tool_preBtn"));
    tool_preBtn->setMinimumSize(QSize(20, 20));
    tool_preBtn->setMaximumSize(QSize(20, 20));
    tool_preBtn->setCursor(QCursor(Qt::PointingHandCursor));
    tool_preBtn->setCheckable(true);
    horizontalLayout->addWidget(tool_preBtn);

    tool_nextBtn = new QPushButton(frame);
    tool_nextBtn->setObjectName(QString::fromUtf8("tool_nextBtn"));
    tool_nextBtn->setMinimumSize(QSize(20, 20));
    tool_nextBtn->setMaximumSize(QSize(20, 20));
    tool_nextBtn->setCursor(QCursor(Qt::PointingHandCursor));
    tool_nextBtn->setCheckable(true);
    horizontalLayout->addWidget(tool_nextBtn);

    tool_timelabel = new QLabel(frame);
    tool_timelabel->setObjectName(QString::fromUtf8("tool_timelabel"));
    tool_timelabel->setMinimumSize(QSize(0, 0));
    tool_timelabel->setMaximumSize(QSize(16777215, 16777215));

    horizontalLayout->addWidget(tool_timelabel);

    horizontalSpacer = new QSpacerItem(198, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    horizontalLayout->addItem(horizontalSpacer);

    tool_volumeBtn = new QPushButton(frame);
    tool_volumeBtn->setObjectName(QString::fromUtf8("tool_volumeBtn"));
    tool_volumeBtn->setMinimumSize(QSize(25, 25));
    tool_volumeBtn->setMaximumSize(QSize(25, 25));
    tool_volumeBtn->setCursor(QCursor(Qt::PointingHandCursor));

    horizontalLayout->addWidget(tool_volumeBtn);

    volumeSlider_ = new Slider(frame);
    volumeSlider_->setObjectName(QString::fromUtf8("volumeSlider"));
    volumeSlider_->setMaximumSize(QSize(200, 16777215));
    volumeSlider_->setOrientation(Qt::Horizontal);

    horizontalLayout->addWidget(volumeSlider_);

    label_volume = new QLabel(frame);
    label_volume->setObjectName(QString::fromUtf8("label_volume"));

    horizontalLayout->addWidget(label_volume);

    tool_fileBtn = new QPushButton(frame);
    tool_fileBtn->setObjectName(QString::fromUtf8("tool_fileBtn"));
    tool_fileBtn->setMinimumSize(QSize(20, 20));
    tool_fileBtn->setMaximumSize(QSize(20, 20));
    tool_fileBtn->setCursor(QCursor(Qt::PointingHandCursor));
    tool_fileBtn->setCheckable(true);

    horizontalLayout->addWidget(tool_fileBtn);

    tool_maxBtn = new QPushButton(frame);
    tool_maxBtn->setObjectName(QString::fromUtf8("tool_maxBtn"));
    tool_maxBtn->setMinimumSize(QSize(20, 20));
    tool_maxBtn->setMaximumSize(QSize(20, 20));
    tool_maxBtn->setCursor(QCursor(Qt::PointingHandCursor));

    horizontalLayout->addWidget(tool_maxBtn);

    horizontalSpacer_3 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

    horizontalLayout->addItem(horizontalSpacer_3);


    verticalLayout->addLayout(horizontalLayout);


    verticalLayout_2->addWidget(frame);


    retranslateUi(ToolFrame);

    QMetaObject::connectSlotsByName(ToolFrame);
}

void ToolFrame::retranslateUi(QFrame *ToolFrame)
{
    ToolFrame->setWindowTitle(QCoreApplication::translate("ToolFrame", "Frame", nullptr));
    tool_playBtn->setText(QString());
    tool_preBtn->setText(QString());
    tool_nextBtn->setText(QString());
    tool_timelabel->setText(QCoreApplication::translate("ToolFrame", "00:00:00/00:00:00", nullptr));
    tool_volumeBtn->setText(QString());
    label_volume->setText(QString());
    tool_fileBtn->setText(QString());
    tool_maxBtn->setText(QString());
}


void ToolFrame::setProxyPlayer(QtAV::AVPlayer *p)
{
    mpPlayer = p;
    m_playListForm->setParent(p->renderer()->widget());

    connect(mpPlayer, SIGNAL(stateChanged(QtAV::AVPlayer::State)), SLOT(onMediaStateChanged()));

}

void ToolFrame::initUi()
{
    m_playListForm = new PlayListForm(this);
    m_playListForm->hide();


    volumeSlider_->setMinimum(0);
    volumeSlider_->setCursor(Qt::PointingHandCursor);
    frame->setMouseTracking(true);
    frame->installEventFilter(this);


    const int kVolumeSliderMax = 100;
    volumeSlider_->setMinimum(0);
    volumeSlider_->setMaximum(kVolumeSliderMax);
    volumeSlider_->setValue(int(1.0/kVolumeInterval*qreal(kVolumeSliderMax)/100.0));

    connect(timeSlider_, SIGNAL(sliderMoved(int)), SLOT(seek(int)));
    connect(timeSlider_, SIGNAL(sliderPressed()), SLOT(seek()));

    connect(timeSlider_, SIGNAL(onLeave()), SLOT(onTimeSliderLeave()));
    connect(timeSlider_, SIGNAL(onHover(int,int)), SLOT(onUpdatePreView(int,int)));

    connect(volumeSlider_, SIGNAL(sliderPressed()), SLOT(setVolume()));
    connect(volumeSlider_, SIGNAL(valueChanged(int)), SLOT(setVolume()));


    connect(m_playListForm,&PlayListForm::sigSelectFile,[&](QString file){

        m_playListForm->hide();
        tool_fileBtn->setChecked(false);

        emit sigSelectFile(file);
    });
}





bool ToolFrame::contanisButtomWidget()
{
    QPoint pos = this->mapFromGlobal(QCursor::pos());

    return frame->geometry().contains(pos);
}

bool ToolFrame::contanisPlaylistWidget()
{
    QPoint pos = mpPlayer->renderer()->widget()->mapFromGlobal(QCursor::pos());

    return m_playListForm->geometry().contains(pos);
}




void ToolFrame::mouseMove(QPoint pos)
{
}

Slider *ToolFrame::timeSlider() const
{
    return timeSlider_;
}

Slider *ToolFrame::volumeSlider() const
{
    return volumeSlider_;
}

QLabel *ToolFrame::timeLabel() const
{
    return tool_timelabel;
}

QPushButton *ToolFrame::playButton() const
{
    return tool_playBtn;
}

QFrame *ToolFrame::buttomWidget() const
{
    return frame;
}




void ToolFrame::seek(int value)
{

    mpPlayer->setSeekType(AccurateSeek);
    mpPlayer->seek((qint64)value);
    if (!m_preview)
        return;
}

void ToolFrame::seek()
{

    seek(timeSlider_->value());
}

void ToolFrame::setVolume()
{
    AudioOutput *ao = mpPlayer ? mpPlayer->audio() : 0;
    qreal v = qreal(volumeSlider_->value())*kVolumeInterval;
    if (ao) {
        if (qAbs(int(ao->volume()/kVolumeInterval) - volumeSlider_->value()) >= int(0.1/kVolumeInterval)) {
            ao->setVolume(v);
        }
    }
    label_volume->setText(QString::number(volumeSlider_->value()));
}

void ToolFrame::onStartPlay()
{
    timeSlider_->setMinimum(mpPlayer->mediaStartPosition());
    timeSlider_->setMaximum(mpPlayer->mediaStopPosition());
    timeSlider_->setValue(0);
    timeSlider_->setEnabled(mpPlayer->isSeekable());
    setVolume();
}

void ToolFrame::onStopPlay()
{
    timeSlider_->setValue(0);
    timeSlider_->setDisabled(true);
    timeSlider_->setMinimum(0);
    timeSlider_->setMaximum(0);
    tool_timelabel->setText(QString::fromLatin1("00:00:00/00:00:00"));

    if (m_preview)
        m_preview->setFile(QString());

}

void ToolFrame::onPositionChange(qint64 pos)
{
    if (mpPlayer->isSeekable())
        timeSlider_->setValue(pos);


    tool_timelabel->setText(QString("%1/%2").arg(QTime(0, 0, 0).addMSecs(pos).toString(QString::fromLatin1("HH:mm:ss")))
                         .arg(QTime(0, 0, 0).addMSecs(mpPlayer->mediaStopPosition()).toString(QString::fromLatin1("HH:mm:ss"))));

}

void ToolFrame::onUpdatePreView(int pos, int value)
{
    if(mpPlayer->isPlaying() == false) return;

    QPoint gpos = this->pos() + QPoint(pos, 0);
    if (!m_preview)
    {
        m_preview = new QtAV::VideoPreviewWidget(mpPlayer->renderer()->widget());
        m_preTimeLabel = new QLabel(m_preview);
        m_preTimeLabel->setAlignment(Qt::AlignBottom | Qt::AlignHCenter);
        m_preTimeLabel->setStyleSheet("color:white;font-size:15px;");
    }

    m_preview->setFile(mpPlayer->file());
    m_preview->setTimestamp(value);
    m_preview->preview();
    const int w = 160;
    const int h = 90;
    m_preview->move(gpos - QPoint(w/2, h));
    m_preview->resize(w, h);
    m_preTimeLabel->resize(w,h);
    m_preTimeLabel->setText(QTime(0, 0, 0).addMSecs(value).toString(QString::fromLatin1("HH:mm:ss")));
    m_preview->show();
    m_preview->raise();

}

void ToolFrame::onTimeSliderLeave()
{
    if (!m_preview)
    {
        return;
    }
    if (m_preview->isVisible())
    {
        m_preview->hide();
    }
}

void ToolFrame::onMediaStateChanged()
{
    switch (mpPlayer->state()) {
    case QtAV::AVPlayer::PlayingState:
    {
        tool_playBtn->setChecked(true);
        tool_stopBtn->setChecked(false);

        tool_preBtn->setChecked(false);
        tool_nextBtn->setChecked(false);

    }
        break;
    case QtAV::AVPlayer::PausedState:
    {
        tool_playBtn->setChecked(false);
    }
        break;
    case QtAV::AVPlayer::StoppedState:
    {
        tool_playBtn->setChecked(false);

        if(tool_stopBtn->isChecked() == true ||
                tool_preBtn->isChecked() == true ||
                tool_nextBtn->isChecked() == true) return;

        switch (m_state) {
        case 0: ///> 单曲循环
        {
            emit sigSelectFile(m_playListForm->currentName());
        }
            break;
        case 1: ///> 顺序循环
        {
            ///> 如果到最后一首，就停止
            if(m_playListForm->currentIndex() == m_playListForm->playsSize() - 1)
            {
                return;
            }
            else
            {
                on_tool_nextBtn_clicked();
            }
        }
            break;
        case 2: ///> 列表循环
        {
            ///> 如果到最后一首，就回到第一首
            if(m_playListForm->currentIndex() == m_playListForm->playsSize() - 1)
            {

                QString name = m_playListForm->playNameByRow(0);
                emit sigSelectFile(name);
                m_playListForm->setCurrentItem(0);
                return;
            }
            else
            {
                on_tool_nextBtn_clicked();
            }
        }
            break;
        default:
            break;
        }

    }
        break;
    default:
        break;
    }
}




void ToolFrame::showEvent(QShowEvent *event)
{
    QApplication::setOverrideCursor(Qt::ArrowCursor);

    m_timer->start();
}

bool ToolFrame::eventFilter(QObject *obj, QEvent *event)
{
    return false;
}






void ToolFrame::sltTimer()
{
    if(contanisButtomWidget() || contanisPlaylistWidget())
    {
        return;
    }

    if(this->isVisible())
    {
        QApplication::setOverrideCursor(Qt::BlankCursor);
        this->hide();
        m_playListForm->hide();
        tool_fileBtn->setChecked(false);
    }

    m_timer->stop();
}




void ToolFrame::on_tool_fileBtn_clicked(bool flag)
{
    QPoint setFramePos = QPoint(m_parentWidget->width() - m_playListForm->width(),
                                m_parentWidget->height() - m_playListForm->height() - this->height());
    m_playListForm->move(setFramePos);

    m_playListForm->setVisible(flag);
}

void ToolFrame::on_tool_maxBtn_clicked()
{
    showFullOrNormal();
}

///> 停止
void ToolFrame::on_tool_stopBtn_clicked()
{
    mpPlayer->stop();
}

void ToolFrame::on_tool_stateBtn_clicked()
{
    m_state++;
    if(m_state > 2)
    {
        m_state = 0;
    }

    switch (m_state) {
    case 0:
        tool_stateBtn->setText("S");
        tool_stateBtn->setToolTip("Single Loop");
        break;
    case 1:
        tool_stateBtn->setText("O");
        tool_stateBtn->setToolTip("Ordered Loop");
        break;
    case 2:
        tool_stateBtn->setText("L");
        tool_stateBtn->setToolTip("List Loop");
        break;
    default:
        break;
    }
}

void ToolFrame::on_tool_preBtn_clicked()
{
    if(m_playListForm->playsSize() == 0)
    {
        tool_preBtn->setChecked(false);
//        m_timer->stop();
//        QMessageBox::warning(NULL,"提示","请先添加音视频文件");
//        m_timer->start();
        return;
    }


    int curIndex = m_playListForm->currentIndex();
    if(m_playListForm->currentIndex() == 0)
    {
        tool_preBtn->setChecked(false);
//        m_timer->stop();
//        QMessageBox::warning(NULL,"提示","当前已是第一个音视频文件");
//        m_timer->start();
        return;

    }

    curIndex -= 1;

    QString name = m_playListForm->playNameByRow(curIndex);

    emit sigSelectFile(name);

    m_playListForm->setCurrentItem(curIndex);
}

void ToolFrame::on_tool_nextBtn_clicked()
{
    if(m_playListForm->playsSize() == 0)
    {
        tool_nextBtn->setChecked(false);
//        m_timer->stop();
//        QMessageBox::warning(NULL,"提示","请先添加音视频文件");
//        m_timer->start();
        return;
    }

    int curIndex = m_playListForm->currentIndex();
    if(curIndex == m_playListForm->playsSize() - 1)
    {
        tool_nextBtn->setChecked(false);
//        m_timer->stop();
//        QMessageBox::warning(NULL,"提示","当前已是最后一个音视频文件");
//        m_timer->start();
        return;

    }

    curIndex += 1;

    QString name = m_playListForm->playNameByRow(curIndex);

    emit sigSelectFile(name);

    m_playListForm->setCurrentItem(curIndex);

}


void ToolFrame::showFullOrNormal()
{
    if (Qt::WindowFullScreen == m_parentWidget->windowState())
    {
        m_parentWidget->setWindowState(m_parentWidget->windowState() ^ Qt::WindowFullScreen);
    }
    else
    {
        m_parentWidget->showFullScreen();
    }

}

void ToolFrame::setVideoIO(VideoOutput *io)
{
    m_playListForm->setVideoIO(io);
}
