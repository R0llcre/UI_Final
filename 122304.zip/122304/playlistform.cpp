#include "playlistform.h"
#include <QFileDialog>
#include <QFileInfo>
#include "setinterface.h"
#include <QtAV>
using namespace QtAV;

PlayListForm::PlayListForm(QWidget *parent) :
    QWidget(parent)
{
    setupUi(this);

    this->setWindowFlags(this->windowFlags() | Qt::FramelessWindowHint);

    SetInterface in(this);
    QStringList files = in.getValue("file","list").toStringList();

    for(QString fileName:files)
    {

        QListWidgetItem* item = new QListWidgetItem;
        item->setText(QFileInfo(fileName).fileName());
        item->setData(Qt::UserRole + 1,fileName);
        item->setToolTip(fileName);

        listWidget->addItem(item);
    }
}

PlayListForm::~PlayListForm()
{
    delete ui;
}

void PlayListForm::setVideoIO(QtAV::VideoOutput *io)
{
    m_io = io;

    horizontalSlider->setValue(m_io->brightness() * 100 + 100);
    horizontalSlider_2->setValue(m_io->contrast() * 100 + 100);
    horizontalSlider_3->setValue(m_io->saturation() * 100 + 100);
    horizontalSlider_4->setValue(m_io->hue() * 100 + 100);

}

int PlayListForm::currentIndex()
{
    return listWidget->currentRow();
}

int PlayListForm::playsSize()
{
    return listWidget->count();
}

QString PlayListForm::playNameByRow(int row)
{
    QListWidgetItem* item = listWidget->item(row);
    if(item)
    {
        return item->data(Qt::UserRole + 1).toString();
    }

    return "";
}

void PlayListForm::setCurrentItem(int row)
{
    listWidget->setCurrentRow(row);
}

QString PlayListForm::currentName()
{
    QListWidgetItem* item = listWidget->currentItem();
    if(item)
    {
        return item->data(Qt::UserRole + 1).toString();
    }

    return "";
}

///> 添加文件
void PlayListForm::on_pushButton_clicked()
{
    QStringList fileNames = QFileDialog::getOpenFileNames(this, tr("Open File"),
                                                    "./",
                                                    tr("Videos (*)"));
    if(fileNames.size() != 0)
    {
        SetInterface in(this);
        QStringList files = in.getValue("file","list").toStringList();

        for(QString fileName:fileNames)
        {
            if(files.contains(fileName) == false)
            {
                QListWidgetItem* item = new QListWidgetItem;
                item->setText(QFileInfo(fileName).fileName());
                item->setData(Qt::UserRole + 1,fileName);
                item->setToolTip(fileName);

                listWidget->addItem(item);

                files.push_back(fileName);
            }
        }


        in.setValue("file","list",files);
    }

}

///> 删除文件
void PlayListForm::on_pushButton_2_clicked()
{
    SetInterface in(this);
    QStringList files = in.getValue("file","list").toStringList();

    QMap<int,int> map;
    auto items = listWidget->selectedItems();
    for(QListWidgetItem* item:items)
    {
        QString path = item->data(Qt::UserRole + 1).toString();

        if(files.contains(path))
        {
            files.removeOne(path);
        }

        map[listWidget->row(item)] = 1;
    }


    in.setValue("file","list",files);

    ///>删除多行
    QMapIterator<int,int> rowMatIterator(map);
    rowMatIterator.toBack();
    while (rowMatIterator.hasPrevious())
    {
        rowMatIterator.previous();
        int row = rowMatIterator.key();
        listWidget->takeItem(row);
    }
}

void PlayListForm::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    emit sigSelectFile(item->data(Qt::UserRole + 1).toString());
}

//> 亮度 -1 and 1
void PlayListForm::on_horizontalSlider_valueChanged(int value)
{
    label_qx_1->setText(QString::number(value));

    m_io->setBrightness(static_cast<double>(value - 100) / 100);
}

//对比度 -1 and 1
void PlayListForm::on_horizontalSlider_2_valueChanged(int value)
{
    label_qx_2->setText(QString::number(value));
    m_io->setContrast(static_cast<double>(value - 100) / 100);
}

//饱和度 -1 and 1
void PlayListForm::on_horizontalSlider_3_valueChanged(int value)
{
    label_qx_3->setText(QString::number(value));
    m_io->setSaturation(static_cast<double>(value - 100) / 100);
}

//色调 -1 and 1
void PlayListForm::on_horizontalSlider_4_valueChanged(int value)
{
    label_qx_4->setText(QString::number(value));
    m_io->setHue(static_cast<double>(value - 100) / 100);
}


void PlayListForm::setupUi(QWidget *PlayListForm)
{
    if (PlayListForm->objectName().isEmpty())
        PlayListForm->setObjectName(QString::fromUtf8("PlayListForm"));
    PlayListForm->resize(280, 350);
    verticalLayout = new QVBoxLayout(PlayListForm);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    tabWidget = new QTabWidget(PlayListForm);
    tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
    tabWidget->setLayoutDirection(Qt::LeftToRight);
    tabWidget->setTabPosition(QTabWidget::South);
    tab = new QWidget();
    tab->setObjectName(QString::fromUtf8("tab"));
    gridLayout = new QGridLayout(tab);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    pushButton = new QPushButton(tab);
    pushButton->setObjectName(QString::fromUtf8("pushButton"));

    gridLayout->addWidget(pushButton, 1, 0, 1, 1);

    pushButton_2 = new QPushButton(tab);
    pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

    gridLayout->addWidget(pushButton_2, 1, 1, 1, 1);

    listWidget = new QListWidget(tab);
    listWidget->setObjectName(QString::fromUtf8("listWidget"));
    listWidget->setSelectionMode(QAbstractItemView::ContiguousSelection);

    gridLayout->addWidget(listWidget, 0, 0, 1, 2);

    tabWidget->addTab(tab, QString());
    tab_2 = new QWidget();
    tab_2->setObjectName(QString::fromUtf8("tab_2"));
    verticalLayout_2 = new QVBoxLayout(tab_2);
    verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
    groupBox = new QGroupBox(tab_2);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    horizontalLayout = new QHBoxLayout(groupBox);
    horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
    horizontalSlider = new QSlider(groupBox);
    horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
    horizontalSlider->setMinimum(1);
    horizontalSlider->setMaximum(100);
    horizontalSlider->setOrientation(Qt::Horizontal);

    horizontalLayout->addWidget(horizontalSlider);

    label_qx_1 = new QLabel(groupBox);
    label_qx_1->setObjectName(QString::fromUtf8("label_qx_1"));

    horizontalLayout->addWidget(label_qx_1);


    verticalLayout_2->addWidget(groupBox);

    groupBox_2 = new QGroupBox(tab_2);
    groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
    horizontalLayout_2 = new QHBoxLayout(groupBox_2);
    horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
    horizontalSlider_2 = new QSlider(groupBox_2);
    horizontalSlider_2->setObjectName(QString::fromUtf8("horizontalSlider_2"));
    horizontalSlider_2->setMinimum(1);
    horizontalSlider_2->setMaximum(100);
    horizontalSlider_2->setOrientation(Qt::Horizontal);

    horizontalLayout_2->addWidget(horizontalSlider_2);

    label_qx_2 = new QLabel(groupBox_2);
    label_qx_2->setObjectName(QString::fromUtf8("label_qx_2"));

    horizontalLayout_2->addWidget(label_qx_2);


    verticalLayout_2->addWidget(groupBox_2);

    groupBox_3 = new QGroupBox(tab_2);
    groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
    horizontalLayout_3 = new QHBoxLayout(groupBox_3);
    horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
    horizontalSlider_3 = new QSlider(groupBox_3);
    horizontalSlider_3->setObjectName(QString::fromUtf8("horizontalSlider_3"));
    horizontalSlider_3->setMinimum(1);
    horizontalSlider_3->setMaximum(100);
    horizontalSlider_3->setOrientation(Qt::Horizontal);

    horizontalLayout_3->addWidget(horizontalSlider_3);

    label_qx_3 = new QLabel(groupBox_3);
    label_qx_3->setObjectName(QString::fromUtf8("label_qx_3"));

    horizontalLayout_3->addWidget(label_qx_3);


    verticalLayout_2->addWidget(groupBox_3);

    groupBox_4 = new QGroupBox(tab_2);
    groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
    horizontalLayout_4 = new QHBoxLayout(groupBox_4);
    horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
    horizontalSlider_4 = new QSlider(groupBox_4);
    horizontalSlider_4->setObjectName(QString::fromUtf8("horizontalSlider_4"));
    horizontalSlider_4->setMinimum(1);
    horizontalSlider_4->setMaximum(100);
    horizontalSlider_4->setOrientation(Qt::Horizontal);

    horizontalLayout_4->addWidget(horizontalSlider_4);

    label_qx_4 = new QLabel(groupBox_4);
    label_qx_4->setObjectName(QString::fromUtf8("label_qx_4"));

    horizontalLayout_4->addWidget(label_qx_4);


    verticalLayout_2->addWidget(groupBox_4);

    tabWidget->addTab(tab_2, QString());

    verticalLayout->addWidget(tabWidget);


    retranslateUi(PlayListForm);

    tabWidget->setCurrentIndex(0);


    QMetaObject::connectSlotsByName(PlayListForm);
} // setupUi

void PlayListForm::retranslateUi(QWidget *PlayListForm)
{
    PlayListForm->setWindowTitle(QCoreApplication::translate("PlayListForm", "Form", nullptr));
    pushButton->setText(QCoreApplication::translate("PlayListForm", "Add", nullptr));
    pushButton_2->setText(QCoreApplication::translate("PlayListForm", "Delete", nullptr));
    tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("PlayListForm", "File Manager", nullptr));
    groupBox->setTitle(QCoreApplication::translate("PlayListForm", "Brightness", nullptr));
    label_qx_1->setText(QCoreApplication::translate("PlayListForm", "1", nullptr));
    groupBox_2->setTitle(QCoreApplication::translate("PlayListForm", "Contrast", nullptr));
    label_qx_2->setText(QCoreApplication::translate("PlayListForm", "1", nullptr));
    groupBox_3->setTitle(QCoreApplication::translate("PlayListForm", "Saturation", nullptr));
    label_qx_3->setText(QCoreApplication::translate("PlayListForm", "1", nullptr));
    groupBox_4->setTitle(QCoreApplication::translate("PlayListForm", "Hue", nullptr));
    label_qx_4->setText(QCoreApplication::translate("PlayListForm", "1", nullptr));
    tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("PlayListForm", "Definition", nullptr));
} // retranslateUi
