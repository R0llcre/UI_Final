﻿#include "setinterface.h"
#include <QCoreApplication>

SetInterface::SetInterface(const QString &filename, QObject *parent) : QObject(parent)
{
    m_set = new QSettings(filename,QSettings::IniFormat,this);
}

SetInterface::SetInterface(QObject *parent) : QObject(parent)
{
    m_set = new QSettings(QSettings::NativeFormat,QSettings::UserScope,QCoreApplication::organizationName(),
                          QCoreApplication::applicationName(),this);
}

SetInterface::~SetInterface()
{
    if(m_set)
    {
        delete m_set;
        m_set = nullptr;
    }
}

void SetInterface::setValue(const QString &groupname, const QString &key, const QVariant &value)
{
    m_set->setValue(QString("%1/%2").arg(groupname).arg(key),value);
}

QVariant SetInterface::getValue(const QString &groupname, const QString &key, QVariant defaultValue)
{
    QVariant value = m_set->value(QString("%1/%2").arg(groupname).arg(key));
    if(value.isNull())
    {
        value = defaultValue;
        m_set->setValue(QString("%1/%2").arg(groupname).arg(key),value);
    }

    return value;
}
