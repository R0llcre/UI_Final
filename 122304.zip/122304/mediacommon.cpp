#include "mediacommon.h"

double g_speedTimeMS = 5000;
