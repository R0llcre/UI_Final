#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QObject>

#include <QtAV>

class MediaPlayer : public QObject
{
    Q_OBJECT
public:
    explicit MediaPlayer(QObject *parent = nullptr);

    ~MediaPlayer();

    QWidget* videoWidget();

    QtAV::AVPlayer* player();

    void setMedia(const QString& file);

    void playPause();

    void stop();

     QtAV::VideoOutput* videoIO();
signals:

protected:

public slots:
    void togglePlayPause();


private:
    QtAV::AVPlayer *m_player;
    QtAV::VideoOutput *m_vo;

    QString m_file;

};

#endif // MEDIAPLAYER_H
