#include "widget.h"

#include "mediaplayer.h"

#include <QDebug>
#include <QFile>
#include <QPushButton>
#include <QVBoxLayout>

#include "eventmanager.h"

#include <QApplication>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    this->resize(900, 700);
    QVBoxLayout* main_verticalLayout = new QVBoxLayout(this);


    loadStyle();

    m_player = new MediaPlayer(this);
    QWidget* widget = m_player->videoWidget();
    widget->setMouseTracking(true);

    main_verticalLayout->addWidget(widget);
    main_verticalLayout->setContentsMargins(0,0,0,0);


    EventManager *mng = new EventManager(m_player->player());
    qApp->installEventFilter(mng);
    mng->setParentWidget(this);


    QVBoxLayout* verticalLayout = new QVBoxLayout(widget);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    QSpacerItem* verticalSpacer = new QSpacerItem(20, 512, QSizePolicy::Minimum, QSizePolicy::Expanding);

    verticalLayout->addItem(verticalSpacer);

    m_toolFrame = new ToolFrame(this);
    m_toolFrame->hide();
    m_toolFrame->setWindowFlags(Qt::Tool | Qt::FramelessWindowHint);
    m_toolFrame->setAttribute(Qt::WA_TranslucentBackground,true);
    m_toolFrame->setProxyPlayer(m_player->player());
    m_toolFrame->setVideoIO(m_player->videoIO());
    m_toolFrame->setParentWidget(this);

    mng->setToolWidget(m_toolFrame);

    verticalLayout->addWidget(m_toolFrame);
    verticalLayout->setContentsMargins(1,1,1,1);


    widget->installEventFilter(this);

    connect(m_toolFrame,SIGNAL(sigSelectFile(QString)),this,SLOT(onSelectFile(QString)));
    connect(m_player->player(), SIGNAL(started()), m_toolFrame, SLOT(onStartPlay()));
    connect(m_player->player(), SIGNAL(stopped()), m_toolFrame, SLOT(onStopPlay()));
    connect(m_player->player(), SIGNAL(positionChanged(qint64)), m_toolFrame, SLOT(onPositionChange(qint64)));

    mpPlayPauseBtn = m_toolFrame->playButton();
    connect(mpPlayPauseBtn, SIGNAL(clicked()), m_player,SLOT(togglePlayPause()));


}

Widget::~Widget()
{
}


void Widget::on_pushButton_clicked(bool flag)
{
    m_player->playPause();
}

void Widget::onSelectFile(QString file)
{

    m_player->setMedia(file);
    m_player->playPause();

}

bool Widget::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == m_player->videoWidget())
    {
        if (event->type() == QEvent::MouseMove)
        {
            m_toolFrame->show();
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        // pass the event on to the parent class
        return QWidget::eventFilter(obj, event);
    }
}



void Widget::loadStyle()
{
    QFile file(":/image/tool/resource/player.qss");
    if(file.open(QIODevice::ReadOnly))
    {
        QByteArray data = file.readAll();
        setStyleSheet(QString::fromUtf8(data));

        file.close();
    }

}
